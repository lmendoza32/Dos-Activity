package com.example.dozactivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SegundoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_segundo)
    }
}